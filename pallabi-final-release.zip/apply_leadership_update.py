#!/usr/bin/env python3
"""Update the Pallabi Hospital repo to publish Papry Rahman as its sole leader.

Usage: python path/to/apply_leadership_update.py /path/to/pallabi-hospital
Run inside a clean git working tree so the changes are easy to inspect/revert.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


OLD_NAMES = [
    "Md Rubel Howlader", "Md Hasan Al Yakut", "Md Jalal Uddin",
    "মোঃ রুবেল হাওলাদার", "মোঃ হাসান আল ইয়াকুত", "মোঃ জালাল উদ্দিন",
]
OLD_ORIGINALS = ["CEO.jpeg", "Managing Director.jpeg", "Director.jpeg"]
OLD_OUTPUTS = ["ceo.webp", "managing-director.webp", "director.webp"]


def replace_once(text: str, before: str, after: str, filename: str) -> str:
    occurrences = text.count(before)
    if occurrences != 1:
        raise RuntimeError(
            f"Expected exactly one matching entry in {filename}, found {occurrences}: {before[:90]!r}. "
            "Your repository may differ from the version reviewed."
        )
    return text.replace(before, after, 1)


def edit_file(path: Path, replacements: list[tuple[str, str]]) -> str:
    original = path.read_text(encoding="utf-8")
    updated = original
    for old, new in replacements:
        updated = replace_once(updated, old, new, str(path))
    return updated


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", nargs="?", default=".", help="Path to pallabi-hospital repository (default: current folder)")
    args = parser.parse_args()
    root = Path(args.repo).resolve()
    files = {
        "config": root / "content/hospital.json",
        "builder": root / "build.py",
        "images": root / "scripts/prepare_images.py",
        "readme": root / "README.md",
        "todo": root / "CONTENT_TODO.md",
    }
    for path in files.values():
        if not path.is_file():
            parser.error(f"Expected repository file missing: {path}")

    config = json.loads(files["config"].read_text(encoding="utf-8"))
    leaders = config.get("leaders", [])
    chairman = [entry for entry in leaders if entry.get("role") == "chairman" and entry.get("name_en") == "Papry Rahman"]
    if len(chairman) != 1:
        raise RuntimeError("Expected exactly one Papry Rahman chairman profile in content/hospital.json")
    config["leaders"] = chairman

    builder = edit_file(files["builder"], [
        (
            "ROLES={'chairman':('Chairman','চেয়ারম্যান'),'ceo':('Chief Executive Officer','প্রধান নির্বাহী কর্মকর্তা'),'managing-director':('Managing Director','ব্যবস্থাপনা পরিচালক'),'director':('Director','পরিচালক')}",
            "ROLES={'chairman':('Chairman','চেয়ারম্যান')}",
        ),
        (
            "Meet the people guiding Pallabi Hospital & Diagnostic Center, and read their messages to patients and families.",
            "Meet Papry Rahman, Chairman of Pallabi Hospital & Diagnostic Center, and read her message to patients and families.",
        ),
        (
            "পল্লবী হাসপাতাল এন্ড ডায়াগনস্টিক সেন্টারের পরিচালনা পর্ষদের সদস্যদের পরিচয় ও তাঁদের বার্তা পড়ুন।",
            "পল্লবী হাসপাতাল এন্ড ডায়াগনস্টিক সেন্টারের চেয়ারম্যান পাপড়ি রহমানের পরিচয় ও তাঁর বার্তা পড়ুন।",
        ),
        (
            's("OUR MANAGEMENT","আমাদের পরিচালনা পর্ষদ",lang)',
            's("CHAIRMAN’S MESSAGE","চেয়ারম্যানের বার্তা",lang)',
        ),
        (
            's("The people behind our commitment to care","সেবার অঙ্গীকারে যাঁরা নেতৃত্ব দিচ্ছেন",lang)',
            's("Meet our Chairman","আমাদের চেয়ারম্যানের পরিচয়",lang)',
        ),
        (
            's("A closer look at the people who help shape the hospital’s direction and everyday priorities.","প্রতিষ্ঠানের লক্ষ্য, পরিচালনা ও সেবার অগ্রাধিকার নির্ধারণে যাঁরা ভূমিকা রাখছেন, তাঁদের পরিচয়।",lang)',
            's("Read Papry Rahman’s message on respectful, compassionate patient care.","সম্মানজনক ও সহমর্মিতাপূর্ণ রোগীসেবা সম্পর্কে পাপড়ি রহমানের বার্তা পড়ুন।",lang)',
        ),
    ])
    images = edit_file(files["images"], [
        (
            "for key,name in [('chairman','Chairman.jpeg'),('ceo','CEO.jpeg'),('managing-director','Managing Director.jpeg'),('director','Director.jpeg')]:",
            "for key,name in [('chairman','Chairman.jpeg')]:",
        ),
        ("print('Prepared 20 images and favicon')", "print('Prepared 17 images and favicon')"),
    ])
    # Avoid serving old webp files during an incremental, local image rebuild.
    insert_at = "logo=Image.open(SRC/'Logo.jpeg').convert('RGBA')"
    cleanup = (
        "# Remove portraits that are no longer published.\n"
        "for stale in ('ceo.webp', 'managing-director.webp', 'director.webp'):\n"
        "    (DEST/stale).unlink(missing_ok=True)\n"
    )
    images = replace_once(images, insert_at, cleanup + insert_at, str(files["images"]))

    readme = edit_file(files["readme"], [
        ("the hospital-provided photographs, logo and management portraits.",
         "the hospital-provided photographs, logo and Chairman portrait."),
        ("Leadership and Management Body pages show four full-width individual profiles, Chairman first and featured larger. Their messages are **drafted website copy requiring management sign-off before publication as personal statements**.",
         "Leadership and Management Body pages show only Papry Rahman, the Chairman, with her portrait and message. Her message is **drafted website copy requiring her approval before publication as a personal statement**."),
        ("**Management:** Papry Rahman (Chairman), Md Rubel Howlader (CEO), Md Hasan Al Yakut (Managing Director), Md Jalal Uddin (Director)",
         "**Leadership:** Papry Rahman (Chairman)"),
    ])
    todo = edit_file(files["todo"], [
        ("Management names supplied: Papry Rahman, Md Rubel Howlader, Md Hasan Al Yakut and Md Jalal Uddin.",
         "Chairman name supplied: Papry Rahman."),
        ("Approve the **four written management messages**: text was composed for this website, not transcribed from the individuals.",
         "Approve **Papry Rahman’s written message**: text was composed for this website, not transcribed from her."),
        ("Confirm the Bengali transliterations of the four management names.",
         "Confirm the Bengali spelling of Papry Rahman's name."),
        ("Approve public use of logo, original photographs, and individual portraits; check photo consent for event attendees.",
         "Approve public use of the logo, hospital photographs, and Papry Rahman's portrait; check photo consent for event attendees."),
    ])

    # Validate all changes before writing any files.
    rendered = json.dumps(config, ensure_ascii=False, indent=2) + "\n"
    for text in (rendered, builder, images, readme, todo):
        for name in OLD_NAMES:
            if name in text:
                raise RuntimeError(f"Found removed name {name!r} in updated source text")
    updates = {
        files["config"]: rendered,
        files["builder"]: builder,
        files["images"]: images,
        files["readme"]: readme,
        files["todo"]: todo,
    }
    for path, content in updates.items():
        path.write_text(content, encoding="utf-8")
        print(f"Updated {path.relative_to(root)}")

    for basename in OLD_ORIGINALS:
        target = root / "source-images" / basename
        if target.is_file():
            target.unlink()
            print(f"Deleted {target.relative_to(root)}")
    for basename in OLD_OUTPUTS:
        target = root / "site/assets/images" / basename
        if target.is_file():
            target.unlink()
            print(f"Deleted {target.relative_to(root)}")

    print("\nDone: Papry Rahman is now the only configured leader.")
    print("Next: run 'python scripts/prepare_images.py' and 'python build.py', then review git diff.")


if __name__ == "__main__":
    main()
