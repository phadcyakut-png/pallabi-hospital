#!/usr/bin/env python3
"""Check photo-card assets and both generated language pages after a local build.
Usage: python verify_gallery_update.py /path/to/pallabi-hospital
"""
from pathlib import Path
from html.parser import HTMLParser
import argparse
import json

class GalleryParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tabs=[]
        self.panels=[]
        self.cards=[]
        self.images=[]
    def handle_starttag(self,tag,attrs):
        attr=dict(attrs)
        if attr.get('data-gallery-tab'):
            self.tabs.append(attr)
        if attr.get('data-gallery-panel'):
            self.panels.append(attr)
        if attr.get('data-filter-target')=='photocards':
            self.cards.append(attr)
        if tag=='img':
            self.images.append(attr)


def verify(repo):
    metadata=json.loads((repo/'content/photocards.json').read_text(encoding='utf-8'))
    assert len(metadata)==14, f'Expected 14 photo cards, got {len(metadata)}'
    for item in metadata:
        stem=Path(item['file']).stem
        assert (repo/'source-images/photocards'/item['file']).is_file(), f'Missing source: {item["file"]}'
        for file in [stem+'.webp',stem+'-preview.webp']:
            assert (repo/'site/assets/images'/file).is_file(), f'Missing built asset: {file}'
    for lang in ('en','bn'):
        page=repo/'site'/lang/'gallery/index.html'
        assert page.is_file(), f'Build missing: {page}'
        html=page.read_text(encoding='utf-8')
        doc=GalleryParser()
        doc.feed(html)
        assert [a['data-gallery-tab'] for a in doc.tabs]==['hospital','photocards'], 'Tabs missing or out of order'
        assert [a['data-gallery-panel'] for a in doc.panels]==['hospital','photocards'], 'Panels missing'
        assert len(doc.cards)==14, f'{lang}: expected 14 photocard gallery buttons, got {len(doc.cards)}'
        assert all(x.get('data-lightbox','').endswith('.webp') for x in doc.cards)
        assert len(set(x['data-lightbox'] for x in doc.cards))==14
        assert all(any(im.get('src','').endswith(Path(m['file']).stem+'-preview.webp') for im in doc.images) for m in metadata)
        assert 'data-filter-set="photocards"' in html
        assert 'data-filter-set="gallery"' in html
        print(f'PASS {lang}: two gallery tabs, 14 photocards, original hospital filters preserved')
    print('PASS all 28 optimized image assets exist')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo')
    opts=parser.parse_args()
    verify(Path(opts.repo).resolve())
