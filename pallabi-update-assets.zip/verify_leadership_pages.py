#!/usr/bin/env python3
"""Check generated English and Bengali pages after running python build.py."""
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repo', nargs='?', default='.')
root = Path(parser.parse_args().repo).resolve()

leaders = json.loads((root/'content/hospital.json').read_text(encoding='utf-8'))['leaders']
assert len(leaders) == 1 and leaders[0]['name_en'] == 'Papry Rahman'
assert leaders[0]['photo'] == 'chairman.webp'

for lang in ('en', 'bn'):
    for slug in ('leadership', 'management'):
        path = root/'site'/lang/slug/'index.html'
        html = path.read_text(encoding='utf-8')
        expected_name = 'Papry Rahman' if lang == 'en' else 'পাপড়ি রহমান'
        assert html.count('class="leadership-row') == 1, f'Expected one profile: {path}'
        assert expected_name in html, f'Missing chairman name: {path}'
        assert 'chairman.webp' in html, f'Missing chairman picture: {path}'
        for omitted in ('Md Rubel Howlader', 'Md Hasan Al Yakut', 'Md Jalal Uddin',
                        'মোঃ রুবেল হাওলাদার', 'মোঃ হাসান আল ইয়াকুত', 'মোঃ জালাল উদ্দিন',
                        'ceo.webp', 'managing-director.webp', 'director.webp'):
            assert omitted not in html, f'Unexpected removed profile in {path}: {omitted}'
        print(f'PASS {path.relative_to(root)}')

for page in (root/'site').rglob('*.html'):
    page_text = page.read_text(encoding='utf-8')
    for omitted in ('Md Rubel Howlader', 'Md Hasan Al Yakut', 'Md Jalal Uddin',
                    'মোঃ রুবেল হাওলাদার', 'মোঃ হাসান আল ইয়াকুত', 'মোঃ জালাল উদ্দিন'):
        assert omitted not in page_text, f'Unexpected removed name in {page}'

for removed in ('ceo.webp', 'managing-director.webp', 'director.webp'):
    assert not (root/'site/assets/images'/removed).exists(), f'Stale portrait: {removed}'
print('PASS — only Papry Rahman appears on leadership-related pages; old photos removed.')
