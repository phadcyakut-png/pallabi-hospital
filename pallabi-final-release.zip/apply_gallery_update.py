#!/usr/bin/env python3
"""Install a bilingual Photo Cards tab in the Pallabi Hospital website.

Usage: python apply_gallery_update.py /path/to/pallabi-hospital
Does not push changes or access GitHub; only modifies the local checkout.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
from pathlib import Path

# The website builder uses s(), E(), photo(), image_src(), page_hero(), and section_title().
# The function below replaces ONLY gallery_page; the other pages are untouched.
GALLERY_FUNCTION = '''def gallery_page(lang,slug):
  intro=page_hero(lang,slug,s('Explore photographs of our hospital spaces and visual highlights from our team and community.','হাসপাতালের পরিবেশের ছবি এবং আমাদের টিম ও কমিউনিটির বিশেষ মুহূর্তের ফটোকার্ড দেখুন।',lang))
  filters=[('all','All Photos','সব ছবি'),('rooms','Patient Rooms','রোগীর কক্ষ'),('diagnostics','Diagnostics','ডায়াগনস্টিক'),('interiors','Interiors','অভ্যন্তরীণ অংশ'),('exterior','Exterior','বাইরের দৃশ্য')]
  buttons=''.join(f'<button class="filterbtn{" active" if val=="all" else ""}" data-filter="{val}" type="button">{E(s(en,bn,lang))}</button>' for val,en,bn in filters)
  cards=''.join(f'<button class="gallery-item" type="button" data-filter-target="gallery" data-category="{cat}" data-lightbox="{E(image_src(lang,slug,f"hospital-{num:02d}.webp"))}" data-alt="{E(s(en,bn,lang))}" data-caption="{E(s(en,bn,lang))}">{photo(lang,slug,f"hospital-{num:02d}.webp",s(en,bn,lang))}<span class="photo-label">{E(s(en,bn,lang))}</span></button>' for num,cat,en,bn in GALLERY)
  card_filters=[('all','All Photo Cards','সব ফটোকার্ড'),('newborn','Newborn Celebrations','নবজাতক উদ্‌যাপন'),('team','Our Team','আমাদের টিম'),('messages','Messages & Feedback','বার্তা ও প্রতিক্রিয়া')]
  card_buttons=''.join(f'<button class="filterbtn{" active" if val=="all" else ""}" data-filter="{val}" type="button">{E(s(en,bn,lang))}</button>' for val,en,bn in card_filters)
  poster_data=json.loads((R/'content/photocards.json').read_text(encoding='utf-8'))
  poster_cards=[]
  for card in poster_data:
   stem=Path(card['file']).stem
   alt=card['caption_'+lang]
   category=card['category']
   full=image_src(lang,slug,stem+'.webp')
   preview=stem+'-preview.webp'
   poster_cards.append(f'<button class="gallery-item photocard-gallery-item" type="button" data-filter-target="photocards" data-category="{E(category)}" data-lightbox="{E(full)}" data-alt="{E(alt)}" data-caption="{E(alt)}" aria-label="{E(s("Open full-size image: ","সম্পূর্ণ ছবি দেখুন: ",lang)+alt)}">{photo(lang,slug,preview,alt)}<span class="photocard-caption">{E(alt)}</span></button>')
  poster_markup=''.join(poster_cards)
  tabs=f'<div class="gallery-collection-tabs" role="tablist" aria-label="{E(s("Gallery collections","গ্যালারির বিভাগ",lang))}"><button type="button" class="gallery-collection-tab active" role="tab" id="tab-hospital" aria-controls="panel-hospital" aria-selected="true" tabindex="0" data-gallery-tab="hospital">{E(s("Hospital Photos","হাসপাতালের ছবি",lang))}</button><button type="button" class="gallery-collection-tab" role="tab" id="tab-photocards" aria-controls="panel-photocards" aria-selected="false" tabindex="-1" data-gallery-tab="photocards">{E(s("Photo Cards","ফটোকার্ড",lang))} <span class="gallery-tab-count">{len(poster_data)}</span></button></div>'
  hospital_panel=f'<section class="gallery-panel" id="panel-hospital" role="tabpanel" aria-labelledby="tab-hospital" data-gallery-panel="hospital"><h3 class="gallery-panel-heading">{E(s("Hospital Photos","হাসপাতালের ছবি",lang))}</h3><p class="gallery-panel-description">{E(s("Explore our facilities, rooms and diagnostic environment.","হাসপাতালের বিভিন্ন কক্ষ, সুযোগ-সুবিধা ও ডায়াগনস্টিক পরিবেশ দেখুন।",lang))}</p><div class="filterbar" data-filter-set="gallery">{buttons}</div><div class="gallery-grid">{cards}</div></section>'
  cards_panel=f'<section class="gallery-panel" id="panel-photocards" role="tabpanel" aria-labelledby="tab-photocards" data-gallery-panel="photocards" hidden><h3 class="gallery-panel-heading">{E(s("Photo Cards & Highlights","ফটোকার্ড ও বিশেষ মুহূর্ত",lang))}</h3><p class="gallery-panel-description">{E(s("Newborn celebrations, our team and community messages. Select a card to view its complete design and text.","নবজাতক উদ্‌যাপন, আমাদের টিম ও বিভিন্ন বার্তা। পুরো ডিজাইন ও লেখা দেখতে ফটোকার্ডে চাপ দিন।",lang))}</p><div class="filterbar" data-filter-set="photocards">{card_buttons}</div><div class="photocard-gallery-grid">{poster_markup}</div></section>'
  dialog=f'<dialog class="dialog" id="gallery-lightbox" aria-label="{E(s("Full size gallery image","গ্যালারির সম্পূর্ণ ছবি",lang))}"><button class="dialog-close" type="button">{E(s("Close ✕","বন্ধ করুন ✕",lang))}</button><div class="dialog-inner"><img src="" alt=""><p></p></div></dialog>'
  return intro+f'<section class="section"><div class="container">{section_title(lang,s("OUR PHOTO GALLERY","আমাদের ফটো গ্যালারি",lang),s("The hospital in pictures","ছবিতে আমাদের হাসপাতাল",lang),s("Browse hospital photographs and commemorative photo cards in separate collections.","হাসপাতালের ছবি ও বিশেষ মুহূর্তের ফটোকার্ড আলাদা বিভাগে দেখুন।",lang))}{tabs}{hospital_panel}{cards_panel}</div></section>{dialog}'
'''

STYLES = r'''
/* Pallabi Photo Cards gallery — independent, uncropped poster grid */
.gallery-collection-tabs{display:flex;gap:10px;flex-wrap:wrap;margin:34px 0 35px;padding:6px;background:#edf4f6;border:1px solid #dbe9ed;border-radius:16px;width:fit-content;max-width:100%}
.gallery-collection-tab{display:inline-flex;align-items:center;gap:9px;background:transparent;border:0;border-radius:11px;padding:11px 20px;color:var(--navy);font-size:.92rem;font-weight:800;white-space:normal;text-align:center}
.gallery-collection-tab.active,.gallery-collection-tab[aria-selected=true]{background:var(--blue);color:white;box-shadow:0 5px 14px #075d852b}
.gallery-collection-tab:focus-visible,.photocard-gallery-item:focus-visible{outline:3px solid #f5ae45;outline-offset:3px}
.gallery-tab-count{background:#ffffff35;padding:0 7px;border-radius:99px;font-size:.75rem}
.gallery-panel[hidden]{display:none!important}
.gallery-panel-heading{font-size:clamp(1.4rem,2.4vw,2rem);color:var(--navy);margin:0 0 5px}
.gallery-panel-description{font-size:.92rem;margin:0;max-width:700px}
.photocard-gallery-grid{columns:3;column-gap:19px;margin-top:24px}
.photocard-gallery-item{display:block;break-inside:avoid;width:100%;overflow:hidden;border:1px solid #e2eaf0;border-radius:17px;background:#fff;box-shadow:0 8px 23px #102f450b;margin-bottom:19px;text-align:left;cursor:zoom-in;transition:box-shadow .2s,transform .2s}
.photocard-gallery-item:hover{transform:translateY(-3px);box-shadow:0 15px 30px #102f451b}
.photocard-gallery-item img{width:100%;height:auto;object-fit:contain;transform:none!important;display:block;background:#f4f7f8}
.photocard-gallery-item .photocard-caption{display:block;padding:12px 15px 14px;color:var(--navy);font-size:.84rem;font-weight:700;line-height:1.5;position:static;background:transparent}
.photocard-gallery-item.hidden{display:none!important}
@media(max-width:900px){.photocard-gallery-grid{columns:2}}
@media(max-width:560px){.photocard-gallery-grid{columns:1}.gallery-collection-tabs{width:100%}.gallery-collection-tab{flex:1;justify-content:center;padding:11px 10px;font-size:.84rem}.photocard-gallery-grid .photocard-gallery-item{margin-bottom:17px}}
'''

JS_TABS = '''  // Switch between hospital photos and uncropped photo-card posters.
  const galleryTabs = Array.from(document.querySelectorAll('[data-gallery-tab]'));
  const galleryPanels = Array.from(document.querySelectorAll('[data-gallery-panel]'));
  function selectGalleryTab(tab, focus = false) {
    if (!tab) return;
    galleryTabs.forEach(item => {
      const selected = item === tab;
      item.classList.toggle('active', selected);
      item.setAttribute('aria-selected', String(selected));
      item.tabIndex = selected ? 0 : -1;
    });
    galleryPanels.forEach(panel => {
      panel.hidden = panel.dataset.galleryPanel !== tab.dataset.galleryTab;
    });
    if (focus) tab.focus();
  }
  galleryTabs.forEach((tab, index) => {
    tab.addEventListener('click', () => selectGalleryTab(tab));
    tab.addEventListener('keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      let next = index;
      if (event.key === 'ArrowLeft') next = (index - 1 + galleryTabs.length) % galleryTabs.length;
      if (event.key === 'ArrowRight') next = (index + 1) % galleryTabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = galleryTabs.length - 1;
      selectGalleryTab(galleryTabs[next], true);
    });
  });
  if (location.hash === '#photo-cards') selectGalleryTab(galleryTabs.find(tab => tab.dataset.galleryTab === 'photocards'));
'''

IMAGE_CODE = '''# Generate gallery photocards and smaller thumbnails from approved originals.
from PIL import ImageOps
import json
cards=json.loads((ROOT/'content/photocards.json').read_text(encoding='utf-8'))
for card in cards:
    source=SRC/'photocards'/card['file']
    if not source.is_file():
        raise FileNotFoundError(f'Missing gallery source image: {source}')
    original=ImageOps.exif_transpose(Image.open(source)).convert('RGB')
    large=original.copy()
    large.thumbnail((1600,2000),Image.Resampling.LANCZOS)
    stem=Path(card['file']).stem
    large.save(DEST/f'{stem}.webp','WEBP',quality=87,method=6)
    preview=original.copy()
    preview.thumbnail((760,980),Image.Resampling.LANCZOS)
    preview.save(DEST/f'{stem}-preview.webp','WEBP',quality=76,method=6)
print(f'Prepared {len(cards)} photo-card originals and thumbnails')
'''


def expect_exactly_one(text: str, fragment: str, filename: str) -> None:
    found = text.count(fragment)
    if found != 1:
        raise RuntimeError(f'{filename}: expected 1 match for {fragment[:75]!r}, found {found}; refusing to guess.')


def modify(root: Path, source: Path) -> None:
    builder = root/'build.py'
    css = root/'site/assets/style.css'
    js = root/'site/assets/app.js'
    prep = root/'scripts/prepare_images.py'
    metadata = root/'content/photocards.json'
    for f in [builder,css,js,prep]:
        if not f.is_file():
            raise FileNotFoundError(f'Missing expected website file: {f}')
    if (metadata.exists() or 'gallery-collection-tabs' in builder.read_text(encoding='utf-8')
            or 'Pallabi Photo Cards gallery' in css.read_text(encoding='utf-8')):
        raise RuntimeError('A photo-card update seems already installed. Inspect the repo first; no files changed.')
    info = json.loads((source/'content/photocards.json').read_text(encoding='utf-8'))
    assert len(info) == 14
    assert len({item['file'] for item in info}) == len(info)
    assert {item['category'] for item in info} == {'newborn', 'team', 'messages'}
    for item in info:
        assert item['file'].startswith('photocard-') and item['file'].endswith('.jpeg')
        assert (source/'source-images/photocards'/item['file']).is_file()
        assert all(item.get(key) for key in ('caption_en','caption_bn'))

    original = builder.read_text(encoding='utf-8')
    begin='def gallery_page(lang,slug):\n'
    end='def news_page(lang,slug):\n'
    expect_exactly_one(original, begin, 'build.py')
    expect_exactly_one(original, end, 'build.py')
    left, rest=original.split(begin,1)
    _,right=rest.split(end,1)
    if 'data-filter-target="gallery"' not in rest.split(end,1)[0]:
        raise RuntimeError('build.py gallery implementation differs from inspected source, refusing to replace')
    newbuilder=left+GALLERY_FUNCTION+end+right

    original_css=css.read_text(encoding='utf-8')
    newcss=original_css.rstrip()+'\n'+STYLES+'\n'

    original_js=js.read_text(encoding='utf-8')
    js_anchor='  const dialog = document.querySelector(\'#gallery-lightbox\');'
    expect_exactly_one(original_js, js_anchor, 'site/assets/app.js')
    newjs=original_js.replace(js_anchor, JS_TABS+js_anchor,1)

    original_prep=prep.read_text(encoding='utf-8')
    # Both the original site and the separate Chairman-only update have this print line.
    prints=re.findall(r"(?m)^print\('Prepared \d+ images and favicon'\)$", original_prep)
    if len(prints)!=1:
        raise RuntimeError('Could not locate the original image-preparation completion message')
    newprep=original_prep.replace(prints[0],IMAGE_CODE+prints[0],1)

    # All source modifications are prepared and syntax-checked before writing.
    compile(newbuilder,str(builder),'exec')
    compile(newprep,str(prep),'exec')
    import subprocess
    if shutil.which('node'):
        check=subprocess.run(['node','--check','-'],input=newjs,text=True,capture_output=True)
        if check.returncode:
            raise RuntimeError('JavaScript validation failed: '+check.stderr)

    for item in info:
        if (root/'source-images/photocards'/item['file']).exists():
            raise RuntimeError(f'Target image already exists: {item["file"]}')
    for file,text in [(builder,newbuilder),(css,newcss),(js,newjs),(prep,newprep)]:
        file.write_text(text,encoding='utf-8')
        print('Updated',file.relative_to(root))
    metadata.write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Added',metadata.relative_to(root))
    dest=root/'source-images/photocards'
    dest.mkdir(parents=True,exist_ok=True)
    for item in info:
        shutil.copy2(source/'source-images/photocards'/item['file'], dest/item['file'])
    print('Copied 14 original photo cards into',dest.relative_to(root))
    print('No GitHub commits were created. Run the image script and builder, then verify the HTML.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo',help='Path to your local pallabi-hospital checkout')
    opts=parser.parse_args()
    modify(Path(opts.repo).resolve(),Path(__file__).resolve().parent)

if __name__=='__main__':
    main()
