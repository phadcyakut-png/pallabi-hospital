#!/usr/bin/env python3
"""One-time import upgrader for Pallabi Hospital's new GitHub repository.

The source repository must already contain the original website. The installer
makes both prior content changes, and leaves permanent build/QA utilities.
"""
from pathlib import Path
import json
import shutil
import subprocess
import sys


def main():
    repo = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
    kit = Path(__file__).resolve().parent
    prerequisites = ['build.py', 'content/hospital.json', 'scripts/prepare_images.py',
                     'site/assets/app.js', 'site/assets/style.css']
    missing = [item for item in prerequisites if not (repo / item).is_file()]
    if missing:
        raise SystemExit('This must be run in the imported Pallabi Hospital website repository. Missing: ' + ', '.join(missing))
    cfg = json.loads((repo/'content/hospital.json').read_text(encoding='utf-8'))
    leaders = cfg.get('leaders', [])
    if len(leaders) == 1 and leaders[0].get('name_en') == 'Papry Rahman':
        print('Leadership update already installed; keeping only Papry Rahman.')
    else:
        subprocess.run([sys.executable, str(kit/'apply_leadership_update.py'), str(repo)], check=True)

    builder = (repo/'build.py').read_text(encoding='utf-8')
    gallery_file = repo/'content/photocards.json'
    if 'gallery-collection-tabs' in builder and gallery_file.is_file():
        print('Photo Cards update already installed; preserving existing gallery data.')
    elif 'gallery-collection-tabs' not in builder and not gallery_file.exists():
        # Existing patch expects assets beside the script in this kit.
        subprocess.run([sys.executable, str(kit/'apply_gallery_update.py'), str(repo)], check=True)
    else:
        raise SystemExit('Partial gallery installation detected; refusing an unsafe overwrite. Check build.py and content/photocards.json.')

    runtime_dst = repo/'scripts/release_runtime.py'
    shutil.copy2(kit/'release_runtime.py', runtime_dst)
    print('Installed permanent site config, caching, SEO and verification tool at scripts/release_runtime.py')

    # This extra note remains in the new repository after the one-time archive is deleted.
    shutil.copy2(kit/'NEW-REPOSITORY.md', repo/'NEW-REPOSITORY.md')
    print('Installed NEW-REPOSITORY.md')

    # Ensure removed portraits stay removed even if the source was already partly updated.
    for name in ('CEO.jpeg', 'Managing Director.jpeg', 'Director.jpeg'):
        (repo/'source-images'/name).unlink(missing_ok=True)
    for name in ('ceo.webp', 'managing-director.webp', 'director.webp'):
        (repo/'site/assets/images'/name).unlink(missing_ok=True)
    print('One-time source upgrade installed.')

if __name__ == '__main__':
    main()
